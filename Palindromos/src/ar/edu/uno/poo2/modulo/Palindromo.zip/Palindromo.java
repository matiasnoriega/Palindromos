package ar.edu.uno.poo2.modulo;
import java.io.*;

public class Palindromo {
	
	public void cortePalabra(String string){
		
	}

	
}

